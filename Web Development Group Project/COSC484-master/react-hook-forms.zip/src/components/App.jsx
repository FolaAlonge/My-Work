import React, { useState } from "react";
import {useForm} from "react-hook-form";

export default function App() {
  
  const { register, handleSubmit } = useForm();

  const onSubmit = (data) => {
    console.log(data);
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <h1>Computer Science Progress Checher</h1>
      <div className="coreSection">
        <h2>Select all completed Core Classes</h2>
        <label htmlFor="core1">Core 1</label>
        <input type="checkbox" name="coreClasses" id="core1" value="core1" ref={register} />
        <label htmlFor="core2">Core 2</label>
        <input type="checkbox" name="coreClasses" id="core2" value="core2" ref={register} />
        <label htmlFor="core3">Core 3</label>
        <input type="checkbox" name="coreClasses" id="core3" value="core3" ref={register} />
        <label htmlFor="core4">Core 4</label>
        <input type="checkbox" name="coreClasses" id="core4" value="core4" ref={register} />
        <label htmlFor="core5">Core 5</label>
        <input type="checkbox" name="coreClasses" id="core5" value="core5" ref={register} />
        <label htmlFor="core6">Core 6</label>
        <input type="checkbox" name="coreClasses" id="core6" value="core6" ref={register} />
        <label htmlFor="core7">Core 7</label>
        <input type="checkbox" name="coreClasses" id="core7" value="core7" ref={register} />
        <label htmlFor="core8">Core 8</label>
        <input type="checkbox" name="coreClasses" id="core8" value="core8" ref={register} />
        <label htmlFor="core9">Core 9</label>
        <input type="checkbox" name="coreClasses" id="core9" value="core9" ref={register} />
        <label htmlFor="core10">Core 10</label>
        <input type="checkbox" name="coreClasses" id="core10" value="core10" ref={register} />
        <label htmlFor="core11">Core 11</label>
        <input type="checkbox" name="coreClasses" id="core11" value="core11" ref={register} />
        <label htmlFor="core12">Core 12</label>
        <input type="checkbox" name="coreClasses" id="core12" value="core12" ref={register} />
        <label htmlFor="core13">Core 13</label>
        <input type="checkbox" name="coreClasses" id="core13" value="core13" ref={register} />
        <label htmlFor="core14">Core 14</label>
        <input type="checkbox" name="coreClasses" id="core14" value="core14" ref={register} />
      </div>
      <div className="majorRequirements">
        <h2>Select all completed Major Requirements</h2>
        <label htmlFor="CIS377">CIS 377</label>
        <input type="checkbox" name="majorClasses" value="CIS377" id="CIS377" ref={register}/>
        <label htmlFor="COSC236">COSC 236</label>
        <input type="checkbox" name="majorClasses" value="COSC236" id="COSC236" ref={register}/>
        <label htmlFor="COSC237">COSC 237</label>
        <input type="checkbox" name="majorClasses" value="COSC237" id="COSC237" ref={register}/>
        <label htmlFor="COSC290">COSC 290</label>
        <input type="checkbox" name="majorClasses" value="COSC290" id="COSC290" ref={register}/>
        <label htmlFor="COSC336">COSC 336</label>
        <input type="checkbox" name="majorClasses" value="COSC336" id="COSC336" ref={register}/>
        <label htmlFor="COSC350">COSC 350</label>
        <input type="checkbox" name="majorClasses" value="COSC350" id="COSC350" ref={register}/>
        <label htmlFor="COSC412">COSC 412</label>
        <input type="checkbox" name="majorClasses" value="COSC412" id="COSC412" ref={register}/>
        <label htmlFor="COSC439">COSC 439</label>
        <input type="checkbox" name="majorClasses" value="COSC439" id="COSC439" ref={register}/>
        <label htmlFor="COSC455">COSC 455</label>
        <input type="checkbox" name="majorClasses" value="COSC455" id="COSC455" ref={register}/>
        <label htmlFor="COSC457">COSC 457</label>
        <input type="checkbox" name="majorClasses" value="COSC457" id="COSC457" ref={register}/>
      </div>
      <div className="mathRequirements">
        <h2>Select all completed Math Requirements</h2>
        <label htmlFor="MATH263">MATH 263</label>
        <input type="checkbox" name="mathClasses" value="MATH263" id="MATH263" ref={register}/>
        <label htmlFor="MATH273">MATH 273</label>
        <input type="checkbox" name="mathClasses" value="MATH273" id="MATH273" ref={register}/>
        <label htmlFor="MATH274">MATH 274</label>
        <input type="checkbox" name="mathClasses" value="MATH274" id="MATH274" ref={register}/>
        <label htmlFor="MATH330">MATH 330</label>
        <input type="checkbox" name="mathClasses" value="MATH330" id="MATH330" ref={register}/>
      </div>
      
      <div className="csElectiveA">
        <h2>Elective group A</h2>
        <label htmlFor="">COSC 417</label>
        <input type="checkbox" name="electiveAClasses" value="COSC417" id="COSC417" ref={register}/>
        <label htmlFor="">COSC 432</label>
        <input type="checkbox" name="electiveAClasses" value="COSC432" id="COSC432" ref={register}/>
        <label htmlFor="">COSC 436</label>
        <input type="checkbox" name="electiveAClasses" value="COSC436" id="COSC436" ref={register}/>
        <label htmlFor="">COSC 459</label>
        <input type="checkbox" name="electiveAClasses" value="COSC459" id="COSC459" ref={register}/>
        <label htmlFor="">COSC 461</label>
        <input type="checkbox" name="electiveAClasses" value="COSC461" id="COSC461" ref={register}/>
        <label htmlFor="">COSC 471</label>
        <input type="checkbox" name="electiveAClasses" value="COSC471" id="COSC471" ref={register}/>
        <label htmlFor="">COSC 483</label>
        <input type="checkbox" name="electiveAClasses" value="COSC483" id="COSC483" ref={register}/>
      </div>
      
      <div className="csElectiveB">
        <h2>Elective group B</h2>
        <label htmlFor="COSC397">COSC 397</label>
        <input type="checkbox" name="electiveBClasses" value="COSC397" id="COSC397" ref={register}/>
        <label htmlFor="COSC431">COSC 431</label>
        <input type="checkbox" name="electiveBClasses" value="COSC431" id="COSC431" ref={register}/>
        <label htmlFor="COSC435">COSC 435</label>
        <input type="checkbox" name="electiveBClasses" value="COSC435" id="COSC435" ref={register}/>
        <label htmlFor="COSC440">COSC 440</label>
        <input type="checkbox" name="electiveBClasses" value="COSC440" id="COSC440" ref={register}/>
        <label htmlFor="COSC442">COSC 442</label>
        <input type="checkbox" name="electiveBClasses" value="COSC442" id="COSC442" ref={register}/>
        <label htmlFor="COSC450">COSC 450</label>
        <input type="checkbox" name="electiveBClasses" value="COSC450" id="COSC450" ref={register}/>
        <label htmlFor="COSC458">COSC 458</label>
        <input type="checkbox" name="electiveBClasses" value="COSC458" id="COSC458" ref={register}/>
        <label htmlFor="COSC465">COSC 465</label>
        <input type="checkbox" name="electiveBClasses" value="COSC465" id="COSC465" ref={register}/>
        <label htmlFor="COSC484">COSC 484</label>
        <input type="checkbox" name="electiveBClasses" value="COSC484" id="COSC484" ref={register}/>
      </div>

      <div className="scienceRequirements">
        <h2>Science Requirements</h2>
        <label htmlFor="ASTR161">ASTR 161</label>
        <input type="checkbox" name="scienceClasses" value="ASTR161" id="ASTR161" ref={register}/>
        <label htmlFor="ASTR181">ASTR 181</label>
        <input type="checkbox" name="scienceClasses" value="ASTR181" id="ASTR181" ref={register}/>
        <label htmlFor="BIOL200">BIOL 200</label>
        <input type="checkbox" name="scienceClasses" value="BIOL200" id="BIOL200" ref={register}/>
        <label htmlFor="BIOL202">BIOL 202</label>
        <input type="checkbox" name="scienceClasses" value="BIOL202" id="BIOL202" ref={register}/>
        <label htmlFor="CHEM131">CHEM 131</label>
        <input type="checkbox" name="scienceClasses" value="CHEM131" id="CHEM131" ref={register}/>
        <label htmlFor="CHEM132">CHEM 132</label>
        <input type="checkbox" name="scienceClasses" value="CHEM132" id="CHEM132" ref={register}/>
        <label htmlFor="GEOL121">GEOL 121</label>
        <input type="checkbox" name="scienceClasses" value="GEOL121" id="GEOL121" ref={register}/>
        <label htmlFor="PHYS241">PHYS 241</label>
        <input type="checkbox" name="scienceClasses" value="PHYS241" id="PHYS241" ref={register}/>
        <label htmlFor="PHYS242">PHYS 242</label>
        <input type="checkbox" name="scienceClasses" value="PHYS242" id="PHYS242" ref={register}/>        
      </div>

      <div className="electiveMathRequirements">
        <label htmlFor="MATH265">MATH265</label>
        <input type="checkbox" name="electiveMathClasses" value="MATH265" id="MATH265" ref={register} />
        <label htmlFor="MATH275">MATH275</label>
        <input type="checkbox" name="electiveMathClasses" value="MATH275" id="MATH275" ref={register} />
        <label htmlFor="MATH314">MATH314</label>
        <input type="checkbox" name="electiveMathClasses" value="MATH314" id="MATH314" ref={register} />
        <label htmlFor="MATH315">MATH315</label>
        <input type="checkbox" name="electiveMathClasses" value="MATH315" id="MATH315" ref={register} />
        <label htmlFor="MATH369">MATH369</label>
        <input type="checkbox" name="electiveMathClasses" value="MATH369" id="MATH369" ref={register} />
        <label htmlFor="MATH374">MATH374</label>
        <input type="checkbox" name="electiveMathClasses" value="MATH374" id="MATH374" ref={register} />
        <label htmlFor="MATH377">MATH377</label>
        <input type="checkbox" name="electiveMathClasses" value="MATH377" id="MATH377" ref={register} />
        <label htmlFor="MATH378">MATH378</label>
        <input type="checkbox" name="electiveMathClasses" value="MATH378" id="MATH378" ref={register} />
        <label htmlFor="MATH435">MATH435</label>
        <input type="checkbox" name="electiveMathClasses" value="MATH435" id="MATH435" ref={register} />
        <label htmlFor="MATH437">MATH437</label>
        <input type="checkbox" name="electiveMathClasses" value="MATH437" id="MATH437" ref={register} />
        <label htmlFor="MATH451">MATH451</label>
        <input type="checkbox" name="electiveMathClasses" value="MATH451" id="MATH451" ref={register} />
      </div>
      
      <input type="submit" />
    </form>
  );
}