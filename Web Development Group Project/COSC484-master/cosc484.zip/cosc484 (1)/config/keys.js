module.exports = {
    mongoURI: "mongodb+srv://kampof1:group5@finalproject-ytb6a.mongodb.net/test?retryWrites=true&w=majority",
    secretOrKey: "secret"
};