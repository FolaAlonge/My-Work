import React from "react";
import SignUp from "./SignUp";
import Login from "./Login";
import { Route } from "react-router-dom";

function App() {
  return (
    <div>
      <Route exact path="/" component={SignUp} />
      <Route exact path="/LogIn" component={Login} />
    </div>
  );
}

export default App;
