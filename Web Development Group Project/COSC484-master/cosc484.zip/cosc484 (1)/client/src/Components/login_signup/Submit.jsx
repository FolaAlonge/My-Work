import React from "react";

function Sumbit() {
  return <input type="submit" value="Submit" id="submit" />;
}

export default Sumbit;
