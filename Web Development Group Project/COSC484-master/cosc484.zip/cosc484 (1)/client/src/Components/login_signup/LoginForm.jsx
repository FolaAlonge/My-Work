import React from "react";
import FormInput from "./FormInput";
import Submit from "./Submit";
import { Link } from "react-router-dom";

function Login() {
  return (
    <form>
      <h1>Log in</h1>
      <FormInput
        type="text"
        placeholder="jhanco1@students.towson.edu"
        label="TU Email"
        id="username"
      />
      <FormInput
        type="text"
        placeholder="********"
        label="Password"
        id="password"
      />
      <Submit />
      <p>
        Don't have an account? <Link to="/">Sign up</Link>.
      </p>
    </form>
  );
}

export default Login;
