import React from "react";

function FormInput(props) {
  return (
    <div className="loginField">
      <label htmlFor={props.id}>{props.label}</label>
      <input type={props.type} placeholder={props.placeholder} id={props.id} />
    </div>
  );
}

export default FormInput;
