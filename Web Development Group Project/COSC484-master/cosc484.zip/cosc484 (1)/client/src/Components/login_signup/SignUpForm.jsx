import React from "react";
import FormInput from "./FormInput";
import Submit from "./Submit";
import { Link } from "react-router-dom";

function SignUpForm() {
  return (
    <form>
      <h1>Sign up</h1>
      <FormInput
        type="text"
        placeholder="John Hancock"
        label="Name"
        id="name"
      />
      <FormInput
        type="text"
        placeholder="jhanco1@students.towson.edu"
        label="TU Email"
        id="username"
      />
      <FormInput
        type="password"
        placeholder="********"
        label="Password"
        id="password"
      />
      <FormInput
        type="password"
        placeholder="********"
        label="Verify Password"
        id="verifyPassword"
      />
      <Submit />
      <p>
        Already have an account? <Link to="/login">Log in</Link>.
      </p>
    </form>
  );
}

export default SignUpForm;
