import React from "react";
import SignUpForm from "./Components/login_signup/SignUpForm";

function SignUp() {
  return <SignUpForm />;
}

export default SignUp;
