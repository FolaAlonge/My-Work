import React from "react";
import LoginForm from "./Components/login_signup/LoginForm";
function LogIn() {
  return <LoginForm />;
}

export default LogIn;
